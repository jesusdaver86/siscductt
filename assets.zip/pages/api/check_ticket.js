// pages/api/check_ticket.js
import pool from './db';

export default async function handler(req, res) {
  if (req.method === 'POST') {
    const { unidOpera } = req.body;
    const fechaActual = new Date().toISOString().split('T')[0]; // Formato YYYY-MM-DD

    try {
      // Verificar si el ticket es válido para la fecha actual
      const [result] = await pool.query(
        'SELECT * FROM tickets WHERE unidOpera = ? AND solofecha = ?',
        [unidOpera.toLowerCase(), fechaActual]
      );

      // Verificar si el ticket es válido pero no para la fecha actual
      const [resulta] = await pool.query(
        'SELECT * FROM tickets WHERE unidOpera = ? AND solofecha <> ? AND active = "1"',
        [unidOpera.toLowerCase(), fechaActual]
      );

      if (result.length > 0) {
        // Ticket válido para la fecha actual
        const ticketData = result[0];
        res.status(200).json({
          message: 'Ticket válido. Proceda a llenar el formulario.',
          data: ticketData,
        });
      } else if (resulta.length > 0) {
        // Ticket válido pero no para la fecha actual
        const ticketData = resulta[0];
        const tiempo = calcularTiempo(ticketData.fecha);
        res.status(200).json({
          message: 'Ya surtió!',
          data: ticketData,
          tiempo,
        });
      } else {
        res.status(400).json({ message: 'Oh no! No está en lista.' });
      }
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: 'Error en la conexión a la base de datos.' });
    }
  } else {
    res.setHeader('Allow', ['POST']);
    res.status(405).end(`Method ${req.method} Not Allowed`);
  }
}

function calcularTiempo(fecha) {
  const ahora = Date.now();
  const fechaObj = new Date(fecha);
  
  if (isNaN(fechaObj.getTime())) {
    return "fecha inválida";
  }

  const segundos = Math.floor((ahora - fechaObj) / 1000);
  
  const intervalos = [
    { nombre: 'año', duracion: 31536000 },
    { nombre: 'mes', duracion: 2592000 },
    { nombre: 'día', duracion: 86400 },
    { nombre: 'hora', duracion: 3600 },
    { nombre: 'minuto', duracion: 60 },
    { nombre: 'segundo', duracion: 1 }
  ];

  for (const intervalo of intervalos) {
    const cuenta = Math.floor(segundos / intervalo.duracion);
    if (cuenta >= 1) {
      return `Hace ${cuenta} ${intervalo.nombre}${cuenta > 1 ? 's' : ''}`;
    }
  }
  
  return 'justo ahora';
}